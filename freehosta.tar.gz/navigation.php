<div id="links">
<a href="index.php">Home</a>          <a href="free-hosting.php">Free Hosting</a>          <a href="premium-hosting.php">Premium Hosting</a>          <a href="domains.php">Domains</a>          <a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a>  </div>

