<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>FreeHosta - Welcome !</title>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.ui.effects.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('.slideshow').cycle({
		fx: 'fade'
	});
});

 $(document).ready(function() {
$('#col1 .button').hover(function() {
$(this).addClass('hover1');
}, function() {
$(this).removeClass('hover1');
});
});
</script>



<link href="css/styles.css" rel="stylesheet" type="text/css">

</head>

<body>
<div id="container">

    <div id="topContainer">	
<? include ('navigation.php'); ?>

      <div id="logo"><a href="index.php"><img src="images/logo.png"/></a></div>
      <div id="blueBox">
      <img src="images/wall.png"/>
        <div id="builder" style="position: absolute; left: 650px; top: -6px; width: 259px; height: 229px">
        <img src="images/girl.png"/>
        </div>
        <div id="blueBoxText">
        <h1><img src="images/check.png" align="absmiddle"/>10GB Disk Space<br/>
        <img src="images/check.png" align="absmiddle"/>100GB Bandwidth<br/>
        <img src="images/check.png" align="absmiddle"/>10 Domain Names<br/>
        <img src="images/check.png" align="absmiddle"/>10 MySQL Databases<br/>
        <img src="images/check.png" align="absmiddle"/>Free Website Builder<br/>
        <img src="images/check.png" align="absmiddle"/>Free Script Installer...</h1>
        </div>
      </div>
    </div>
    
    <p>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organisations on the internet. Sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.</p>

    <div id="content">
       <div id="col1">
        <a href="free-hosting.php">
        <h2><center>Free Hosting</center>
        <hr/>
        </h2>
        <p>Instant activation free hosting with PHP, MySQL, FTP, File manager, Website Builder, automatic script installer and much more !</p>
        <p style="text-align: center">
        <br/>
        </a>
      	<img border="0" src="images/s1.png" width="246" height="174"><a href="free-hosting.php">
        </p>
        </p>
        </a>
      </div>

      <div id="col2">
        <a href="premium-hosting.php">
        <h2><center>Premium Hosting</center>
        <hr/>
        </h2>
		<p>Unlimited disk space, no daily hit limits, 256 Softiculious script installer and many more features not included in free hosting package !</p>
        <p style="text-align: center">
        <br/>
        </a>
      	<img border="0" src="images/s2.png" width="246" height="174"><a href="premium-hosting.php">        
		</p>
        </p>
        </a>
      </div>

      <div id="col3">
        <a href="domains.html">
        <h2><center>Domain Registration</center>
        <hr/>
        </h2>
		<p>Get your own domain name such as a .COM .NET .ORG .BIZ .US .EU .INFO and many more for the best prices with free WHOIS privacy included !</p>
        <p style="text-align: center">
        <br/>
        </a>
      	<img border="0" src="images/s3.png" width="246" height="174"><a href="domains.html">        
		</p>
        </p>
        </a>
      </div>
      
      <div id="col4">
        </br>
		<h2>Why use our hosting service ?</h2>
		<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightening fast website speeds. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers !</p>
      </div> 

	<!-- Footer -->
      
      <div id="bottomContainer">
      <hr/>
        
        <img border="0" src="images/footer-logo.png" width="192" height="50">
        <span class="bold">FreeHostam 2013 © All Rights Reserved</span>

      </div>
    </div>
</div>
</body>
</html>
