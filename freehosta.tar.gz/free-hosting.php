<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>FreeHosta - Free Hosting</title>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.ui.effects.js"></script>
<script type="text/javascript" src="../bugs.jquery.com/view/trunk/plugins/validate/jquery.validate.html"></script>
<script type="text/javascript" src="js/validate.js"></script>


<script type="text/javascript" src="../cloud.github.com/downloads/malsup/cycle/jquery.cycle.all.latest.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('.slideshow').cycle({
		fx: 'fade' 
	});
});

 $(document).ready(function() {
$('#col1 .button').hover(function() {
$(this).addClass('hover1');
}, function() {
$(this).removeClass('hover1');
});
});
</script>



<link href="css/styles.css" rel="stylesheet" type="text/css">

</head>

<body>
<div id="container">

    <div id="topContainer">	
<? include ('navigation.php'); ?>
      <div id="logo"><a href="index.php"><img src="images/logo.png"/></a></div>
      <div id="blueBox">
      <img src="images/wall.png"/>
        <div id="builder" style="position: absolute; left: 650px; top: -6px; width: 259px; height: 229px">
        <img src="images/girl.png"/>
        </div>
        <div id="blueBoxText">
        <h1><img src="images/check.png" align="absmiddle"/>10GB Disk Space<br/>
        <img src="images/check.png" align="absmiddle"/>100GB Bandwidth<br/>
        <img src="images/check.png" align="absmiddle"/>10 Domain Names<br/>
        <img src="images/check.png" align="absmiddle"/>10 MySQL Databases<br/>
        <img src="images/check.png" align="absmiddle"/>Free Website Builder<br/>
        <img src="images/check.png" align="absmiddle"/>Free Script Installer...</h1>
        </div>
      </div>
    </div>

    <div id="content">
        
	<div id="col4">
    <p class="bigBold">Complete the registration form below to apply for free hosting !</p>
	</br>
	</br>
    </div>
  
      <img id="toolhouse" src="images/sign-up.png"/>
    
    <center><iframe  src="signup.php" frameborder="0" scrolling="auto" width="500" height="600" marginwidth="0" marginheight="0" ></iframe></center>
    
      <div id="col4">
        </br>
		<h2>Why use our hosting service ?</h2>
		<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightening fast website speeds. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers !</p>
      </div> 

	<!-- Footer -->
      
      <div id="bottomContainer">
      <hr/>
        
        <img border="0" src="images/footer-logo.png" width="192" height="50">
        <span class="bold">FreeHostam 2013 © All Rights Reserved</span>

      </div>
    </div>
    
</div>
</body>
</html>
